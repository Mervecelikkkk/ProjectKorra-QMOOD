package com.projectkorra.projectkorra.attribute;

public enum AttributePriority {

	LOW, MEDIUM, HIGH;

}
